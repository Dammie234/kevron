<template>
  <div>
    <page-header></page-header>
    <page-nav active="contact"></page-nav>
    <!-- Page Banner -->
    <div class="page-banner banner-bg-one">
      <div class="container">
        <div class="banner-text">
          <h1>Contact</h1>
          <nav aria-label="breadcrumb">
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="/">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page">Contact</li>
            </ol>
          </nav>
        </div>
      </div>
    </div>
    <section class="contact-us-section ptb-100 white-bg">
      <div class="container">
        <div class="row justify-content-center">
          <div class="col-md-8 col-lg-8">
            <ul class="course-accordion mt-30">
              <li class="course-accordion-list">
                <h4 class="ca-section-title">Lagos</h4>

                <div class="course-accordion-content" style="display: none">
                  <div class="course-section-content">
                    <div class="row p-4">
                      <div class="col-lg-4">
                        <h5 class="primary-color" style="font-size: 16px">Director</h5>
                        <h6 class="primary-color">
                          Engr. Kayode V. Fowode CFIOSH, FNSE, FNISafetyE
                        </h6>
                        <p>info@kevrongroup.com</p>
                      </div>
                      <div class="col-lg-4">
                        <h5 class="primary-color" style="font-size: 16px">Address</h5>
                        <address>
                          4C Akinola Cole Crescent,<br />
                          Adeniyi Jones, Ikeja, Lagos
                        </address>
                      </div>
                      <div class="col-lg-4">
                        <h5 class="primary-color" style="font-size: 16px">Telephone</h5>
                        <p>
                          +234 201 342 4578, <br />
                          +234 706 392 1439, <br />
                          +234 908 890 8891, <br />
                          +234 708 653 8967, <br />
                          +234 803 976 4250
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </li>

              <li class="course-accordion-list">
                <h4 class="ca-section-title">Port Harcourt</h4>

                <div class="course-accordion-content">
                  <div class="course-section-content">
                    <div class="row p-4">
                      <div class="col-lg-4">
                        <h5 class="primary-color" style="font-size: 16px">Director</h5>
                        <h6 class="primary-color">Yemi Awode</h6>
                        <p>info@kevrongroup.com</p>
                      </div>
                      <div class="col-lg-4">
                        <h5 class="primary-color" style="font-size: 16px">Address</h5>
                        <address>
                          32 Wopara Street, <br />
                          Rumuobiakani, Port Harcourt, <br />
                          Rivers State
                        </address>
                      </div>
                      <div class="col-lg-4">
                        <h5 class="primary-color" style="font-size: 16px">Telephone</h5>
                        <p>
                          +234 201 342 4578, <br />
                          +234 706 392 1439, <br />
                          +234 908 890 8891, <br />
                          +234 708 653 8967, <br />
                          +234 803 976 4250
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
              </li>
              <li class="course-accordion-list">
                <h4 class="ca-section-title">Ghana</h4>

                <div class="course-accordion-content" style="display: none">
                  <div class="course-section-content">
                    <div class="row p-4">
                      <div class="col-lg-5">
                        <h5 class="primary-color" style="font-size: 16px">Director</h5>
                        <h6 class="primary-color">Nicholas Okorie</h6>
                        <p>n.okori@kevrongroup.com</p>
                      </div>
                      <div class="col-lg-7">
                        <h5 class="primary-color" style="font-size: 16px">Address</h5>
                        <address>
                          5 Suhum Street, <br />
                          Kokomlemle, <br />
                          Accra
                        </address>
                      </div>
                    </div>
                  </div>
                </div>
              </li>
              <li class="course-accordion-list">
                <h4 class="ca-section-title">South Africa</h4>

                <div class="course-accordion-content" style="display: none">
                  <div class="course-section-content">
                    <div class="row p-4">
                      <div class="col-lg-4">
                        <h5 class="primary-color" style="font-size: 16px">Director</h5>
                        <h6 class="primary-color">Cyril Ererobe</h6>
                        <p>c.ererobe@kevrongroup.com</p>
                      </div>
                      <div class="col-lg-4">
                        <h5 class="primary-color" style="font-size: 16px">Address</h5>
                        <address>
                          18 Setter Street, <br />
                          Honeydew, <br />
                          Guateng, 2170
                        </address>
                      </div>
                      <div class="col-lg-4">
                        <h5 class="primary-color" style="font-size: 16px">Telephone</h5>
                        <p>+27784146411</p>
                      </div>
                    </div>
                  </div>
                </div>
              </li>
              <li class="course-accordion-list">
                <h4 class="ca-section-title">United Kingdom</h4>

                <div class="course-accordion-content" style="display: none">
                  <div class="course-section-content">
                    <div class="row p-4">
                      <div class="col-lg-4">
                        <h5 class="primary-color" style="font-size: 16px">Director</h5>
                        <h6 class="primary-color">
                          Engr. Kayode Fowode CFIOSH, FNSE, FNISafetyE
                        </h6>
                        <p>k.fowode@kevrongroup.com</p>
                      </div>
                      <div class="col-lg-4">
                        <h5 class="primary-color" style="font-size: 16px">Address</h5>
                        <address>
                          17 Washington Close, <br />
                          Ipswich, Suffolk, <br />
                          IP2 8FT
                        </address>
                      </div>
                      <div class="col-lg-4">
                        <h5 class="primary-color" style="font-size: 16px">Telephone</h5>
                        <p>+447473274822</p>
                      </div>
                    </div>
                  </div>
                </div>
              </li>
            </ul>
          </div>
        </div>
        <div class="row justify-content-center mt-5">
          <div class="col-md-8 col-lg-8">
            <div class="contact-form">
              <form @submit.prevent="processContact">
                <div class="row">
                  <div class="col-lg-6">
                    <div class="form-group">
                      <input
                        type="text"
                        class="form-control"
                        id="name"
                        v-model="form.name"
                        placeholder="Name"
                        required=""
                      />
                      <div class="text-danger" v-if="errors.name">
                        {{ errors.name[0] }}
                      </div>
                    </div>
                  </div>

                  <div class="col-lg-6">
                    <div class="form-group">
                      <input
                        type="email"
                        class="form-control"
                        id="email"
                        v-model="form.email"
                        placeholder="Email"
                        required=""
                      />
                      <div class="text-danger" v-if="errors.email">
                        {{ errors.email[0] }}
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-6">
                    <div class="form-group">
                      <input
                        type="text"
                        class="form-control"
                        id="email"
                        v-model="form.phone"
                        placeholder="Phone Number"
                        required=""
                      />
                      <div class="text-danger" v-if="errors.phone">
                        {{ errors.phone[0] }}
                      </div>
                    </div>
                  </div>
                  <div class="col-lg-6">
                    <div class="form-group">
                      <input
                        type="text"
                        class="form-control"
                        id="msg_subject"
                        placeholder="Subject"
                        required=""
                        v-model="form.subject"
                      />
                      <div class="text-danger" v-if="errors.subject">
                        {{ errors.subject[0] }}
                      </div>
                    </div>
                  </div>
                </div>

                <div class="form-group">
                  <textarea
                    class="form-control"
                    id="message"
                    rows="5"
                    placeholder="Message"
                    v-model="form.message"
                    data-error="Write your message"
                    required=""
                  ></textarea>
                  <div class="help-block with-errors"></div>
                </div>

                <div class="row justify-content-center">
                  <div class="col-lg-2">
                    <button type="submit" class="btn default-btn">Submit</button>
                  </div>
                  <div class="col-lg-1">
                    <div class="clock-loader" v-if="loading"></div>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>

    <page-footer></page-footer>
  </div>
</template>
<script>
export default {
  name: "contact",
  data() {
    return {
      form: {
        name: null,
        email: null,
        subject: null,
        phone: null,
        message: null,
      },
      loading: false,
      errors: {},
    };
  },
  methods: {
    processContact() {
      this.loading = true;
      axios
        .post("/api/process-contact", this.form)
        .then((res) => {
          Toast.fire({
            icon: "success",
            title: "Form Successfully Delivered",
          });
          window.location.href = "/";
        })
        .catch((error) => (this.errors = error.response.data.errors))
        .finally(() => {
          this.loading = false;
        });
    },
  },
};
</script>
